package com.lms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name ="loan_application")
public class LoanApplication
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="applicationIdSeq")
	@SequenceGenerator(name="applicationIdSeq", sequenceName="application_id_seq")
	private int applicationId;
	
	private java.util.Date applicationDate;
	
	@Column(length =10)
	private String loanProgram;
	private double amountOfLoan;
	
	@Column(length= 30)
	private String addressOfProperty;
	private int annualFamilyIncome;
	
	@Column (length=50)
	private String documentProofsAvailable;
	
	@Column(length =20)
	private String guranteeCover;
	private int marketValueOfGuranteeCover;
	
	@Column(length =10)
	private String status;
	private java.util.Date dateOfInterview;
	
	@OneToOne(mappedBy="applicationId")
	private CustomerDetails customer;
	
	@OneToOne(mappedBy="approvedLoan")
	private ApprovedLoans approvedLoan;
	
	public LoanApplication() 
	{
		super();
	}

	public LoanApplication(int applicationId, java.util.Date applicationDate,
			String loanProgram, double amountOfLoan, String addressOfProperty,
			int annualFamilyIncome, String documentProofsAvailable,
			String guranteeCover, int marketValueOfGuranteeCover,
			String status, java.util.Date dateOfInterview,
			CustomerDetails customer, ApprovedLoans approvedLoan) {
		super();
		this.applicationId = applicationId;
		this.applicationDate = applicationDate;
		this.loanProgram = loanProgram;
		this.amountOfLoan = amountOfLoan;
		this.addressOfProperty = addressOfProperty;
		this.annualFamilyIncome = annualFamilyIncome;
		this.documentProofsAvailable = documentProofsAvailable;
		this.guranteeCover = guranteeCover;
		this.marketValueOfGuranteeCover = marketValueOfGuranteeCover;
		this.status = status;
		this.dateOfInterview = dateOfInterview;
		this.customer = customer;
		this.approvedLoan = approvedLoan;
	}

	public int getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}

	public java.util.Date getApplicationDate() {
		return applicationDate;
	}

	public void setApplicationDate(java.util.Date applicationDate) {
		this.applicationDate = applicationDate;
	}

	public String getLoanProgram() {
		return loanProgram;
	}

	public void setLoanProgram(String loanProgram) {
		this.loanProgram = loanProgram;
	}

	public double getAmountOfLoan() {
		return amountOfLoan;
	}

	public void setAmountOfLoan(double amountOfLoan) {
		this.amountOfLoan = amountOfLoan;
	}

	public String getAddressOfProperty() {
		return addressOfProperty;
	}

	public void setAddressOfProperty(String addressOfProperty) {
		this.addressOfProperty = addressOfProperty;
	}

	public int getAnnualFamilyIncome() {
		return annualFamilyIncome;
	}

	public void setAnnualFamilyIncome(int annualFamilyIncome) {
		this.annualFamilyIncome = annualFamilyIncome;
	}

	public String getDocumentProofsAvailable() {
		return documentProofsAvailable;
	}

	public void setDocumentProofsAvailable(String documentProofsAvailable) {
		this.documentProofsAvailable = documentProofsAvailable;
	}

	public String getGuranteeCover() {
		return guranteeCover;
	}

	public void setGuranteeCover(String guranteeCover) {
		this.guranteeCover = guranteeCover;
	}

	public int getMarketValueOfGuranteeCover() {
		return marketValueOfGuranteeCover;
	}

	public void setMarketValueOfGuranteeCover(int marketValueOfGuranteeCover) {
		this.marketValueOfGuranteeCover = marketValueOfGuranteeCover;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public java.util.Date getDateOfInterview() {
		return dateOfInterview;
	}

	public void setDateOfInterview(java.util.Date dateOfInterview) {
		this.dateOfInterview = dateOfInterview;
	}

	public CustomerDetails getCustomer() {
		return customer;
	}

	public void setCustomer(CustomerDetails customer) {
		this.customer = customer;
	}

	public ApprovedLoans getApprovedLoan() {
		return approvedLoan;
	}

	public void setApprovedLoan(ApprovedLoans approvedLoan) {
		this.approvedLoan = approvedLoan;
	}

		
}
