package com.lms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "LoanProgramsOffered")
public class LoanProgramsOffered {

	@Id
	@Column(length = 5)
	private String programName;
	@Column(length = 20)
	private String description;
	@Column(length = 20)
	private String type;
	private int durationInYears;
	private int minLoanAmount;
	private int maxLoanAmount;
	private int rateOfInterest;
	@Column(name = "proofs_required", length = 20)
	private String proofsRequired;
	public LoanProgramsOffered() {
		super();
	}
	public LoanProgramsOffered(String programName, String description, String type, int durationInYears,
			int minLoanAmount, int maxLoanAmount, int rateOfInterest, String proofsRequired) {
		super();
		this.programName = programName;
		this.description = description;
		this.type = type;
		this.durationInYears = durationInYears;
		this.minLoanAmount = minLoanAmount;
		this.maxLoanAmount = maxLoanAmount;
		this.rateOfInterest = rateOfInterest;
		this.proofsRequired = proofsRequired;
	}
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getDurationInYears() {
		return durationInYears;
	}
	public void setDurationInYears(int durationInYears) {
		this.durationInYears = durationInYears;
	}
	public int getMinLoanAmount() {
		return minLoanAmount;
	}
	public void setMinLoanAmount(int minLoanAmount) {
		this.minLoanAmount = minLoanAmount;
	}
	public int getMaxLoanAmount() {
		return maxLoanAmount;
	}
	public void setMaxLoanAmount(int maxLoanAmount) {
		this.maxLoanAmount = maxLoanAmount;
	}
	public int getRateOfInterest() {
		return rateOfInterest;
	}
	public void setRateOfInterest(int rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}
	public String getProofsRequired() {
		return proofsRequired;
	}
	public void setProofsRequired(String proofsRequired) {
		this.proofsRequired = proofsRequired;
	}
	@Override
	public String toString() {
		return "LoanProgramsOffered [programName=" + programName + ", description=" + description + ", type=" + type
				+ ", durationInYears=" + durationInYears + ", minLoanAmount=" + minLoanAmount + ", maxLoanAmount="
				+ maxLoanAmount + ", rateOfInterest=" + rateOfInterest + ", proofsRequired=" + proofsRequired + "]";
	}

	
}
