package com.lms.view;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.lms.entity.CustomerDetails;
import com.lms.entity.LoanProgramsOffered;
import com.lms.entity.Users;
import com.lms.exception.LmsException;
import com.lms.service.AdminServiceImpl;
import com.lms.service.CustomerServiceImpl;
import com.lms.service.IAdminService;
import com.lms.service.ICustomerService;
import com.lms.service.ILadService;
import com.lms.service.IUserService;
import com.lms.service.LadServiceImpl;
import com.lms.service.UserServiceImpl;

public class Main {

	public static void main(String[] args) throws NumberFormatException,
			IOException, LmsException {
		IUserService userservice = new UserServiceImpl();
		IAdminService adminService = new AdminServiceImpl();
		Users users = new Users();
		ICustomerService customerService = new CustomerServiceImpl();
		CustomerDetails customer = new CustomerDetails();
		ILadService lad= new LadServiceImpl();
		LoanProgramsOffered loanProgramOffered = new LoanProgramsOffered();

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		int ch;
		System.out.println("-----------------------------------");
		System.out.println("Welcome to ABC Banking");
		System.out.println("Press 1 to visit as customer");
		System.out.println("Press 2 to enter as a LAD");
		System.out.println("Press 3 to enter as a Admin");
		System.out.println("Press 0 to exit");
		System.out.println("-----------------------------------");
		ch = Integer.parseInt(br.readLine());

		switch (ch) {
		//CUSTOMER
		case 1:
            CustomerMain customerMain= new CustomerMain();
            customerMain.CustomerMainFunc();
			break;
        //LAD
		case 2:

			LadFunctions ladFunctions= new LadFunctions();
			ladFunctions.ladFunction();
		
        //ADMIN
		case 3:
			AdminFunctions adminFunctions= new AdminFunctions();
			adminFunctions.AdminOperations();
			}

	}

}
