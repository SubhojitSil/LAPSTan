package com.lms.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.persistence.EntityManager;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.lms.dao.IUserDao;
import com.lms.dao.UserDaoImpl;
import com.lms.entity.Users;
import com.lms.exception.LmsException;
import com.lms.util.JPAUtil;

public class UserServiceImpl implements IUserService {
	static Logger logger=Logger.getRootLogger();
	private EntityManager entityManager;

 private IUserDao userDao;
 public UserServiceImpl() {
userDao = new UserDaoImpl(); 

	entityManager = JPAUtil.getEntityManager();
	PropertyConfigurator.configure("resources/log4j.properties");
}

	@Override
	public boolean addUser(Users users) throws LmsException {
		userDao.addUser(users);
		logger.info("successful");
		return userDao.addUser(users);
	}
	@Override
	public boolean authenticUser(String[] credential) throws LmsException {
		boolean isAuthentic=userDao.authenticUser(credential);
		logger.info("successful");
		return isAuthentic;
	}

	@Override
	public boolean validateCredentials(String[] credential) throws LmsException {
		logger.info("validating Credentials");
		Pattern uNamePattern = Pattern.compile("[A-Za-z]{1,5}");
		Matcher uNameMatcher = uNamePattern.matcher(credential[0]);
		Pattern pwsdPattern = Pattern.compile("[A-Za-z0-9]{1,10}");
		Matcher pwsdMatcher = pwsdPattern.matcher(credential[1]);
		Pattern rolePattern = Pattern.compile("[A-Za-z]{1,5}");
		Matcher roleMatcher = rolePattern.matcher(credential[2]);
		if(!(uNameMatcher.matches()) && !(pwsdMatcher.matches()) && !(roleMatcher.matches()) )
		return false;
		else 
			return true;
	}
}
