package com.lms.service;

import javax.persistence.EntityManager;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.lms.dao.CustomerDaoImpl;
import com.lms.dao.ICustomerDao;
import com.lms.entity.CustomerDetails;
import com.lms.entity.LoanApplication;
import com.lms.exception.LmsException;
import com.lms.util.JPAUtil;

public class CustomerServiceImpl implements ICustomerService 
{
	static Logger logger=Logger.getRootLogger();
	private EntityManager entityManager;
	
	public CustomerServiceImpl() {
		entityManager = JPAUtil.getEntityManager();
		PropertyConfigurator.configure("resources/log4j.properties");
	}
	ICustomerDao customerDao = new CustomerDaoImpl();
	@Override
	public int registerCustomer(CustomerDetails customer) throws LmsException {
		logger.info("successful");
		return customerDao.registerCustomer(customer);
	}

	@Override
	public int applyLoan(LoanApplication loan) throws LmsException {
		logger.info("successful");
		return customerDao.applyLoan(loan);
	}

	@Override
	public LoanApplication viewApplicationStatus(int applicationId)
			throws LmsException {
		logger.info("successful");
		return customerDao.viewApplicationStatus(applicationId);
	}

}
