package com.lms.dao;

import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.lms.entity.ApprovedLoans;
import com.lms.entity.LoanApplication;
import com.lms.entity.LoanProgramsOffered;
import com.lms.exception.LmsException;
import com.lms.util.JPAUtil;

public class LadDaoImpl implements ILadDao {
	static Logger logger=Logger.getRootLogger();
	private EntityManager entityManager;

	public LadDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
		PropertyConfigurator.configure("resources//log4j.properties");
	}

	
/*********************************************************************************
	 *  - Author        : LMS TEAM 
	 *  - Creation Date : Dec,2017
	 *  - Function      : isRejected()
	 *  - Return type   : boolean
	 *  - Description   : To set the status of loan as rejected
	 *  - Exception     : LmsException
*********************************************************************************/
	@Override
	public boolean isRejected(int applicationId) throws LmsException {
		boolean isupdated = false;
		LoanApplication loanApplication;

		try {
			loanApplication = entityManager.find(LoanApplication.class,
					applicationId);

			if (loanApplication != null) {
				entityManager.getTransaction().begin();
				loanApplication.setStatus("Rejected");
				entityManager.getTransaction().commit();
				isupdated = true;
			}
		} catch (Exception e) {
			logger.error("failed ");
			throw new LmsException(e.getMessage());
		}
		logger.info("successful");
		return isupdated;
	}

/*********************************************************************************
	 *  - Author        : LMS TEAM 
	 *  - Creation Date : Dec,2017
	 *  - Function      : isInterviewDatedUpdated()
	 *  - Return type   : boolean
	 *  - Description   : To update the date of the interview
	 *  - Exception     : LmsException
*********************************************************************************/
	
	@Override
	public boolean isInterviewDatedUpdated(int loanApplicationId, int noOfDays)
			throws LmsException {

		boolean isUpdated = false;
		LoanApplication loanApplication;

		loanApplication = entityManager.find(LoanApplication.class,
				loanApplicationId);

		try {
			if (loanApplication != null) {
				entityManager.getTransaction().begin();
				LocalDate interviewDate = LocalDate.now();
				Date date = java.sql.Date.valueOf(interviewDate);
				Calendar cal = Calendar.getInstance();
				cal.setTime(date);
				cal.add(Calendar.DATE, noOfDays); // adding no of days
				date = cal.getTime();
				
				loanApplication.setDateOfInterview(date);
				loanApplication.setStatus("Accepted");
				
				entityManager.getTransaction().commit();
				isUpdated = true;
			}
		} catch (Exception e) {
			logger.error("failed ");
			throw new LmsException(e.getMessage());
		}
		logger.info("successful");
		return isUpdated;
	}
	
/*********************************************************************************
	 *  - Author        : LMS TEAM 
	 *  - Creation Date : Dec,2017
	 *  - Function      : isApprovedOrRejectedAfterinterview()
	 *  - Return type   : boolean
	 *  - Description   : To update the status of loan after interview
	 *  - Exception     : LmsException
*********************************************************************************/	

	@Override
	public boolean isApprovedOrRejectedAfterinterview(int loanApplicationId, String status)
			throws LmsException {
            boolean isUpdated= false;
		LoanApplication loanApplication;
		
		loanApplication = entityManager.find(LoanApplication.class, loanApplicationId);
		
		try {
			if(loanApplication != null){
			entityManager.getTransaction().begin();
			 loanApplication.setStatus(status);
			
			entityManager.getTransaction().commit();
			isUpdated= true;	
			}
		} catch (Exception e) {
			logger.error("failed ");
			throw new LmsException(e.getMessage());
		}
		
		logger.info("successful");
		return isUpdated;
	}

/*********************************************************************************
	 *  - Author        : LMS TEAM 
	 *  - Creation Date : Dec,2017
	 *  - Function      : isAdded()
     *  - Return type   : boolean
	 *  - Description   : To add the approved loans
	 *  - Exception     : LmsException
*********************************************************************************/	
	@Override
	public boolean isAdded(ApprovedLoans approvedLoans) throws LmsException {
	boolean isInserted= false;
	 entityManager.getTransaction().begin();
	  entityManager.persist(approvedLoans);
	entityManager.getTransaction().commit();
		return isInserted;
	}

/*********************************************************************************
	 *  - Author        : LMS TEAM 
	 *  - Creation Date : Dec,2017
	 *  - Function      : findLoan()
	 *  - Description   : To find a specific loan application
	 *  - Exception     : LmsException
*********************************************************************************/	
	@Override
	public LoanApplication findLoan(int id) throws LmsException {
		LoanApplication searchedLoan= entityManager.find(LoanApplication.class, id);
		return searchedLoan;
	}


@Override
public List<LoanApplication> viewAllApplication() throws LmsException {
	List<LoanApplication> allApplication;
	
	TypedQuery<LoanApplication> qry = entityManager.createQuery(
			"from LoanApplication", LoanApplication.class);

	allApplication = qry.getResultList();
	return allApplication;
}

}
