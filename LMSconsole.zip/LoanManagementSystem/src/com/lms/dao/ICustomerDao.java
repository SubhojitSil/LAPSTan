package com.lms.dao;

import com.lms.entity.CustomerDetails;
import com.lms.entity.LoanApplication;
import com.lms.exception.LmsException;

public interface ICustomerDao 
{
	public int registerCustomer(CustomerDetails customer)throws LmsException;
	public int applyLoan( LoanApplication loan) throws LmsException;
	public LoanApplication viewApplicationStatus(int applicationId) throws LmsException;
}
